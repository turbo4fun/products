<?php
// source: C:\xampp\htdocs\nette\produkty\app\Presenters/templates/Homepage/default.latte

use Latte\Runtime as LR;

class Template89cb6ef39c extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (!$this->getReferringTemplate() || $this->getReferenceType() === "extends") {
			if (isset($this->params['category'])) trigger_error('Variable $category overwritten in foreach on line 6');
		}
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>
	
          
<?php
		$productCount = 0;
?>
                 
<?php
		$iterations = 0;
		foreach ($iterator = $this->global->its[] = new LR\CachingIterator($categories) as $category) {
?>
    
    
<?php
			if ($category->IsProduct == "0" && !$iterator->first) {
?>
	        <br>
<?php
			}
			elseif ($category->IsProduct == "1" && $productCount == 0) {
?>
             -  
<?php
			}
?>
                
<?php
			if ($category->IsProduct == "0") {
				$productCount = 0;
				for ($i = 1;
				$i < $category->Level;
				$i++) {
?>
  	         &nbsp;&nbsp
<?php
				}
			}
			else {
				$productCount++;
?>
           
<?php
				if ($productCount > 1) {
?>
            ,
<?php
				}
?>
           
           
           
<?php
			}
?>

         <?php echo LR\Filters::escapeHtmlText($category->Name) /* line 31 */ ?>

         
<?php
			$iterations++;
		}
		array_pop($this->global->its);
		$iterator = end($this->global->its);
?>
    
    
<?php
	}

}
