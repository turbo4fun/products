-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Počítač: 127.0.0.1
-- Vytvořeno: Čtv 09. led 2020, 11:55
-- Verze serveru: 10.4.8-MariaDB
-- Verze PHP: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáze: `nette`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `category`
--

CREATE TABLE `category` (
  `CategoryId` int(11) NOT NULL,
  `CategoryParent` int(11) DEFAULT NULL,
  `CategoryName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Vypisuji data pro tabulku `category`
--

INSERT INTO `category` (`CategoryId`, `CategoryParent`, `CategoryName`) VALUES
(1, NULL, 'Elektronika'),
(2, 1, 'Televize'),
(3, 1, 'Telefony'),
(4, 3, 'Mobilní telefony'),
(5, NULL, 'Sport'),
(6, NULL, 'Potraviny'),
(7, 5, 'Míčové sporty');

-- --------------------------------------------------------

--
-- Struktura tabulky `product`
--

CREATE TABLE `product` (
  `ProductName` varchar(255) NOT NULL,
  `CategoryId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Vypisuji data pro tabulku `product`
--

INSERT INTO `product` (`ProductName`, `CategoryId`) VALUES
('BRAVA TV', 2),
('XIAOMI', 4),
('SONY', 2),
('SAMSUNG', 2);

-- --------------------------------------------------------

--
-- Zástupná struktura pro pohled `v_category`
-- (See below for the actual view)
--
CREATE TABLE `v_category` (
`OrderPath` varchar(100)
,`CategoryId` int(3)
,`Level` bigint(12)
,`CategoryName` varchar(255)
);

-- --------------------------------------------------------

--
-- Zástupná struktura pro pohled `v_category_product`
-- (See below for the actual view)
--
CREATE TABLE `v_category_product` (
`OrderPath` varchar(100)
,`CategoryId` int(11)
,`Level` bigint(21)
,`Name` varchar(255)
,`IsProduct` int(1)
);

-- --------------------------------------------------------

--
-- Struktura pro pohled `v_category`
--
DROP TABLE IF EXISTS `v_category`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_category`  AS  with recursive tree as (select -10 AS `CategoryId`,NULL AS `CategoryParent`,cast('XXXX' as char(100) charset utf8mb4) AS `CategoryName`,1 AS `LEVEL`,cast('root' as char(100) charset utf8mb4) AS `path` union all select `c2`.`CategoryId` AS `CategoryId`,ifnull(`c2`.`CategoryParent`,-10) AS `IFNULL(c2.CategoryParent, -10)`,cast(`c2`.`CategoryName` as char(100) charset utf8mb4) AS `CAST(c2.CategoryName AS VARCHAR(100))`,`tree`.`LEVEL` + 1 AS `LEVEL`,cast(concat(`tree`.`path`,'/',right(concat('000000000',cast(`c2`.`CategoryId` as char(100) charset utf8mb4)),10)) as char(100) charset utf8mb4) AS `Path` from (`category` `c2` join `tree` on(`tree`.`CategoryId` = ifnull(`c2`.`CategoryParent`,-10))))select `tree`.`path` AS `OrderPath`,`tree`.`CategoryId` AS `CategoryId`,`tree`.`LEVEL` - 1 AS `Level`,`a`.`CategoryName` AS `CategoryName` from (`tree` left join `category` `a` on(`a`.`CategoryId` = `tree`.`CategoryId`)) where `tree`.`path` <> 'root' order by `tree`.`path` ;

-- --------------------------------------------------------

--
-- Struktura pro pohled `v_category_product`
--
DROP TABLE IF EXISTS `v_category_product`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_category_product`  AS  select `t`.`OrderPath` AS `OrderPath`,`t`.`CategoryId` AS `CategoryId`,`t`.`Level` AS `Level`,`t`.`Name` AS `Name`,`t`.`IsProduct` AS `IsProduct` from (select `a`.`OrderPath` AS `OrderPath`,`a`.`CategoryId` AS `CategoryId`,`a`.`Level` AS `Level`,`a`.`CategoryName` AS `Name`,0 AS `IsProduct` from `v_category` `a` union all select `a`.`OrderPath` AS `OrderPath`,`a`.`CategoryId` AS `CategoryId`,`a`.`Level` + 1 AS `Level`,`b`.`ProductName` AS `Name`,1 AS `IsProduct` from (`product` `b` left join `v_category` `a` on(`a`.`CategoryId` = `b`.`CategoryId`))) `t` order by `t`.`OrderPath`,`t`.`IsProduct`,`t`.`Name` ;

--
-- Klíče pro exportované tabulky
--

--
-- Klíče pro tabulku `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`CategoryId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
